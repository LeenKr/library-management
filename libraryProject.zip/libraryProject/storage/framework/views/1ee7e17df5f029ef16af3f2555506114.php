<?php $__env->startSection('head_content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('body_content'); ?>
<div class="form-container">
    <h2>Borrow Book</h2>
    <p>Please fill in your details to proceed with borrowing.</p>

    <form action="<?php echo e(url('/borrow/' . $book_id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Full Name</label>
            <input type="text" id="name" name="name" placeholder="Enter your full name" required>
        </div>

        <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" id="email" name="email" placeholder="Enter your email" required>
        </div>

        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" placeholder="Enter your password" required>
        </div>

        <button type="submit" class="btn-submit">Submit Request</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user/layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Leenk\tpLaravelProject\libraryProject\resources\views/user/borrow.blade.php ENDPATH**/ ?>