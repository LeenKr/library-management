<?php $__env->startSection('head_content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('body_content'); ?>
<div class="books-container">
    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card book-card">
        <img class="card-img-top" src="<?php echo e(asset('/images/'.$b->photo)); ?>" alt="Book Cover">
        <div class="card-body">
            <h4 class="card-title"><?php echo e($b->title); ?></h4>
            <p class="card-text">Year: <?php echo e($b->year); ?></p>
            <p class="card-text">Author: <?php echo e($b->author); ?></p>
            <a href="/borrow/<?php echo e($b->id); ?>" class="btn btn-primary">Borrow</a>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php if(session('success')): ?>
    <div id="success-message" class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <script>
        // Display the success message for 5 seconds and then redirect
        setTimeout(function() {
            window.location.href = "<?php echo e(route('books')); ?>"; // Redirect to the books page
        }, 5000); // 5000 milliseconds = 5 seconds
    </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user/layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Leenk\tpLaravelProject\libraryProject\resources\views/user/viewBooks.blade.php ENDPATH**/ ?>