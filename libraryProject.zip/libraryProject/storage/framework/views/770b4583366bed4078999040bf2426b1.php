<?php $__env->startSection('body_container'); ?>
    <form action="" method="post" enctype="multipart/form-data">
        <table class="table">
            <tr>
                <th>Title</th>
                <th>Author</th>
                <th>Year</th>
                <th>photo</th>
                <th>copies available</th>
                <th>Action</th>
            </tr>
            <tbody id="table_rows">
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="row_<?php echo e($book->id); ?>">
                        <td>
                            <div class="mb-3 mt-3">
                                <input type="text" class="form-control" id="txtTitle_<?php echo e($book->id); ?>"
                                    value="<?php echo e($book->title); ?>" name="txtTitle_<?php echo e($book->id); ?>">
                            </div>
                        </td>
                        <td>
                            <div class="mb-3 mt-3">
                                <input type="text" class="form-control" id="txtAuthor_<?php echo e($book->id); ?>"
                                    value="<?php echo e($book->author); ?>" name="txtAuthor_<?php echo e($book->id); ?>">
                            </div>
                        </td>
                        <td>
                            <div class="mb-3 mt-3">
                                <input type="number" class="form-control" id="txtYear_<?php echo e($book->id); ?>"
                                    value="<?php echo e($book->year); ?>" name="txtYear_<?php echo e($book->id); ?>">
                            </div>
                        </td>

                        <td>
                            <div class="mb-3 mt-3">
                                <?php if($book->photo != null && file_exists(public_path() . '/images/' . $book->photo)): ?>
                                    <img src="<?php echo e(asset('images/' . $book->photo)); ?>" alt="" width="75"
                                        id="img_<?php echo e($book->id); ?>">
                                <?php endif; ?>
                                <input type="file" class="form-control" id="txtPhoto_<?php echo e($book->id); ?>"
                                    name="txtPhoto_<?php echo e($book->id); ?>">
                            </div>
                        </td>
                        <td>
                            <div class="mb-3 mt-3">
                                <input type="number" class="form-control" id="txtCopies_<?php echo e($book->id); ?>"
                                    value="<?php echo e($book->copies_available); ?>" name="txtCopies_<?php echo e($book->id); ?>">
                            </div>
                        </td>
                        <td>
                            <button type="button" class="btn btn-primary" onclick="updateBook(<?php echo e($book->id); ?>)"
                                id="btnUpdate_<?php echo e($book->id); ?>">Update</button>
                            <button type="button" class="btn btn-primary" onclick="deleteBook(<?php echo e($book->id); ?>)"
                                id="btnDelete_<?php echo e($book->id); ?>">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tr>
                <td>New Book</td>
            </tr>
            <tr id="row_0">
                <td>
                    <div class="mb-3 mt-3">
                        <input type="text" class="form-control" id="txtTitle_0" placeholder="book title"
                            name="txtTitle_0">
                    </div>
                </td>
                <td>
                    <div class="mb-3 mt-3">
                        <input type="text" class="form-control" id="txtAuthor_0" placeholder="author name"
                            name="txtAuthor_0">
                    </div>
                </td>
                <td>
                    <div class="mb-3 mt-3">
                        <input type="number" class="form-control" id="txtYear_0" placeholder="year" name="txtYear_0">
                    </div>
                </td>

                <td>
                    <div class="mb-3 mt-3">
                        <input type="file" class="form-control" id="txtPhoto_0" name="txtPhoto_0">
                    </div>
                </td>
                <td>

                    <div class="mb-3 mt-3">
                        <input type="number" class="form-control" id="txtCopies_0" placeholder="copies available"
                            name="txtCopies_0">

                    </div>
                </td>
                <td>
                    <button type="button" class="btn btn-primary" id="btnAdd">Add</button>
                </td>
            </tr>
        </table>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Leenk\tpLaravelProject\libraryProject\resources\views/admin/addBook.blade.php ENDPATH**/ ?>