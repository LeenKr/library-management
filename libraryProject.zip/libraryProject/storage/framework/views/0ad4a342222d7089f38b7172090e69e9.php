<?php $__env->startSection('head_content'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/library.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('body_content'); ?>

<div class="container">
    <div class="row align-items-center library-section">
        <div class="col-md-6">
            <img src="<?php echo e(asset('images/library.jpg')); ?>" class="img-fluid library-image" alt="Library Image">
        </div>
        <div class="col-md-6 library-content">
            <h2>Welcome to SouLeen Library</h2>
            <p>
                Books are the gateway to knowledge, imagination, and personal growth. At SouLeen Library, we offer a vast collection of books across various genres to inspire, educate, and entertain. Reading enhances creativity, improves focus, and expands your understanding of the world.
            </p>
            <p><strong>Why Should You Read Books?</strong></p>
            <ul>
                <li>Boosts cognitive skills and memory.</li>
                <li>Reduces stress and enhances mental well-being.</li>
                <li>Improves vocabulary and communication skills.</li>
                <li>Encourages critical thinking and problem-solving.</li>
            </ul>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user/layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Leenk\tpLaravelProject\libraryProject\resources\views/user/description.blade.php ENDPATH**/ ?>